#!/usr/bin/env python3
"""Generate or edit images through the recipient's configured Images API."""

from __future__ import annotations

import argparse
import base64
import binascii
import hashlib
import json
import mimetypes
import os
from pathlib import Path
import re
import sqlite3
import sys
import time
from typing import Any, Iterable
import urllib.error
import urllib.parse
import urllib.request
import uuid

sys.path.insert(0, str(Path(__file__).resolve().parent))
try:
    from postprocess import PostprocessError, parse_output_size, process_many
except ImportError:  # pragma: no cover
    from .postprocess import PostprocessError, parse_output_size, process_many


DEFAULT_MODEL = "gpt-image-2"
DEFAULT_BASE_URL = "https://eos.manyuvip.com"
ALLOWED_BASE_HOST = "eos.manyuvip.com"
MAX_RESPONSE_BYTES = 100 * 1024 * 1024
MAX_IMAGE_BYTES = 50 * 1024 * 1024
MAX_EDGE = 3840
MIN_PIXELS = 655_360
MAX_PIXELS = 14_745_600
MAX_INPUT_IMAGES = 16
SUPPORTED_IMAGE_MIME = {"image/png", "image/jpeg", "image/webp", "image/gif"}
SUPPORTED_MODELS = ("gpt-image-2", "gpt-image-2-pro")
SKILL_VERSION = "1.8.13"
PROMPT_MAX_CHARS = 1024
PROMPT_COMPACT_TARGET = 1000
EDIT_MAX_EDGE = 1792
AUTO_ASYNC_REFERENCE_COUNT = 6
AUTO_ASYNC_REFERENCE_BYTES = 48 * 1024 * 1024


class ImageGenError(RuntimeError):
    pass


def _environment_value(name: str) -> str:
    value = os.environ.get(name, "").strip()
    if value:
        return value
    if os.name == "nt":
        try:
            import winreg

            with winreg.OpenKey(winreg.HKEY_CURRENT_USER, "Environment") as key:
                value, _ = winreg.QueryValueEx(key, name)
            if isinstance(value, str):
                return value.strip()
        except (FileNotFoundError, OSError):
            pass
    return ""


def _nested_strings(value: Any, key_name: str) -> list[str]:
    found: list[str] = []
    if isinstance(value, dict):
        for key, child in value.items():
            if key == key_name and isinstance(child, str):
                found.append(child.strip())
            else:
                found.extend(_nested_strings(child, key_name))
    elif isinstance(value, list):
        for child in value:
            found.extend(_nested_strings(child, key_name))
    return [item for item in found if item]


def _provider_values(raw: str) -> tuple[str, str]:
    try:
        settings = json.loads(raw)
    except (json.JSONDecodeError, TypeError):
        return "", ""
    if not isinstance(settings, dict):
        return "", ""

    config = settings.get("config", {})
    urls = _nested_strings(config, "base_url")
    if isinstance(config, str):
        urls.extend(re.findall(r"base_url\s*=\s*[\"']([^\"']+)[\"']", config))

    auth = settings.get("auth", {})
    if isinstance(auth, str):
        try:
            auth = json.loads(auth)
        except json.JSONDecodeError:
            match = re.search(
                r"OPENAI_API_KEY\s*[=:]\s*[\"']?([^\s\"']+)", auth
            )
            auth = {"OPENAI_API_KEY": match.group(1)} if match else {}
    keys = _nested_strings(auth, "OPENAI_API_KEY")
    return (urls[0].strip() if urls else "", keys[0].strip() if keys else "")


def _discover_current_cc_switch_provider() -> tuple[str, str, str] | None:
    db_path = Path.home() / ".cc-switch" / "cc-switch.db"
    if not db_path.is_file():
        return None

    try:
        with sqlite3.connect(f"file:{db_path.as_posix()}?mode=ro", uri=True) as db:
            row = db.execute(
                "SELECT settings_config FROM providers "
                "WHERE app_type = 'codex' AND is_current = 1 LIMIT 1"
            ).fetchone()
    except (sqlite3.Error, OSError) as exc:
        raise ImageGenError("Unable to read the current CC Switch configuration") from exc

    if not row:
        return None
    base_url, key = _provider_values(row[0] or "")
    if base_url and key:
        return base_url, key, "CC Switch current Codex provider"
    return None


def _paired_environment(
    prefix: str, default_base_url: str = ""
) -> tuple[str, str] | None:
    base_url = _environment_value(f"{prefix}_BASE_URL")
    key = _environment_value(f"{prefix}_API_KEY")
    if not base_url and key and default_base_url:
        base_url = default_base_url
    if bool(base_url) != bool(key):
        raise ImageGenError(
            f"{prefix}_BASE_URL and {prefix}_API_KEY must be configured together"
        )
    return (base_url, key) if base_url and key else None


def discover_credentials() -> tuple[str, str, str, str]:
    configured = _paired_environment("IMAGEGEN", DEFAULT_BASE_URL)
    if configured:
        base_url, key = configured
        source = "environment"
    else:
        configured = _paired_environment("OPENAI")
        if configured:
            base_url, key = configured
            source = "environment"
        else:
            current = _discover_current_cc_switch_provider()
            if not current:
                raise ImageGenError(
                    "No image API configuration found. Set IMAGEGEN_BASE_URL and "
                    "IMAGEGEN_API_KEY, set OPENAI_BASE_URL and OPENAI_API_KEY, or "
                    "select a compatible Codex provider in CC Switch"
                )
            base_url, key, source = current

    model = _environment_value("IMAGEGEN_MODEL") or DEFAULT_MODEL
    return base_url, key, model, source


def _validate_base_url(base_url: str) -> tuple[urllib.parse.ParseResult, str]:
    try:
        parsed = urllib.parse.urlparse(base_url.strip())
        port = parsed.port
    except ValueError as exc:
        raise ImageGenError("The image API base URL is invalid") from exc
    if parsed.scheme not in {"http", "https"} or not parsed.hostname:
        raise ImageGenError("The image API base URL must be an HTTP or HTTPS URL")
    if parsed.scheme == "http" and parsed.hostname not in {"localhost", "127.0.0.1", "::1"}:
        raise ImageGenError("Non-local image API connections must use HTTPS")
    if parsed.username or parsed.password:
        raise ImageGenError("The image API base URL must not contain credentials")
    normalized_host = (parsed.hostname or "").rstrip(".").lower()
    if normalized_host != ALLOWED_BASE_HOST:
        raise ImageGenError(
            f"This Skill only supports the configured image relay: {ALLOWED_BASE_HOST}"
        )

    netloc = parsed.hostname
    if ":" in netloc and not netloc.startswith("["):
        netloc = f"[{netloc}]"
    if port is not None:
        netloc = f"{netloc}:{port}"
    return parsed._replace(netloc=netloc), parsed.path.rstrip("/")


def image_endpoint(base_url: str, operation: str) -> str:
    if operation not in {"generations", "edits"}:
        raise ImageGenError("Unsupported image operation")
    parsed, path = _validate_base_url(base_url)
    operation_path = f"/images/{operation}"
    if path.endswith(operation_path):
        endpoint_path = path
    elif path.endswith("/v1"):
        endpoint_path = path + operation_path
    else:
        endpoint_path = path + "/v1" + operation_path
    return urllib.parse.urlunparse(
        parsed._replace(path=endpoint_path, params="", query="", fragment="")
    )


def generation_endpoint(base_url: str) -> str:
    """Return the generations endpoint (kept for callers of the original script)."""
    return image_endpoint(base_url, "generations")


def edit_endpoint(base_url: str) -> str:
    return image_endpoint(base_url, "edits")


def validate_size(size: str) -> str:
    match = re.fullmatch(r"([1-9]\d*)x([1-9]\d*)", size.strip().lower())
    if not match:
        raise ImageGenError("Size must use WIDTHxHEIGHT, for example 1024x1024")
    width, height = int(match.group(1)), int(match.group(2))
    if width > MAX_EDGE or height > MAX_EDGE:
        raise ImageGenError("Image size must not exceed 3840px on either edge")
    if width % 16 or height % 16:
        raise ImageGenError("Image width and height must both be multiples of 16px")
    long_edge, short_edge = max(width, height), min(width, height)
    if long_edge > short_edge * 3:
        raise ImageGenError("Long edge to short edge ratio must not exceed 3:1")
    pixels = width * height
    if pixels < MIN_PIXELS or pixels > MAX_PIXELS:
        raise ImageGenError(
            f"Total pixels must be between {MIN_PIXELS:,} and {MAX_PIXELS:,}"
        )
    return f"{width}x{height}"


def edit_working_size(size: str) -> str:
    """Preserve the requested edit size; the provider decides its own limits."""
    return validate_size(size)


def default_aspect_ratio(size: str, requested: str = "") -> str:
    """Use a comic-friendly portrait ratio only when the caller omitted one."""
    explicit = requested.strip()
    if explicit:
        return explicit
    width, height = (int(value) for value in size.split("x"))
    return "2:3" if height > width else ""


_SAFETY_PROMPT_REWRITES = (
    (re.compile(r"(?i)\b(?:bloodied|bloody|bleeding|blood|gore|gory)\b"), "cinematic action"),
    (re.compile(r"(?i)\b(?:dismemberment|dismembered|decapitation|decapitate|severed limbs?)\b"), "non-graphic action"),
    (re.compile(r"(?i)\b(?:kill|killing|killed|murder|murdered|massacre|torture|torturing)\b"), "defeat"),
    (re.compile(r"(?i)\b(?:violent|violence|brutal|brutality)\b"), "dramatic"),
    (re.compile(r"血腥|血液|流血|鲜血|喷血|肢解|断肢|断头|砍头|斩首|虐杀|屠杀|谋杀|杀死|杀害|暴力|残暴|残忍"), "电影化动作"),
)


def sanitize_prompt(prompt: str) -> tuple[str, bool]:
    """Rewrite graphic injury language once, locally, without adding a retry."""
    sanitized = prompt
    changed = False
    for pattern, replacement in _SAFETY_PROMPT_REWRITES:
        sanitized, count = pattern.subn(replacement, sanitized)
        changed = changed or bool(count)
    if changed:
        sanitized = (
            f"{sanitized.rstrip()}\n"
            "cinematic, non-graphic action; clean presentation; no injury detail"
        )
    return sanitized, changed


def compact_prompt(prompt: str) -> tuple[str, bool]:
    """Keep prompts within the upstream limit without a second billed request."""
    if len(prompt) <= PROMPT_MAX_CHARS:
        return prompt, False
    target = min(PROMPT_COMPACT_TARGET, PROMPT_MAX_CHARS)
    head = max(16, int(target * 0.72))
    tail = max(16, target - head)
    compacted = f"{prompt[:head].rstrip()}\n{prompt[-tail:].lstrip()}"
    return compacted[:PROMPT_MAX_CHARS], True


def request_fingerprint(
    prompt: str,
    model: str,
    size: str,
    mode: str,
    quality: str,
    image_paths: list[str],
    mask_path: str | None,
) -> str:
    digest = hashlib.sha256()
    for value in (prompt, model, size, mode, quality or ""):
        digest.update(value.encode("utf-8"))
        digest.update(b"\0")
    for path in image_paths + ([mask_path] if mask_path else []):
        if not path:
            continue
        digest.update(str(Path(path).expanduser().resolve()).encode("utf-8"))
        digest.update(b"\0")
        with Path(path).expanduser().open("rb") as handle:
            for chunk in iter(lambda: handle.read(1024 * 1024), b""):
                digest.update(chunk)
    return digest.hexdigest()


def _read_limited(response: Any, limit: int) -> bytes:
    data = response.read(limit + 1)
    if len(data) > limit:
        raise ImageGenError("The API response exceeded the local safety limit")
    return data


def _safe_http_detail(exc: urllib.error.HTTPError, key: str) -> str:
    detail = exc.read(8192).decode("utf-8", errors="replace")
    if key:
        detail = detail.replace(key, "[redacted]")
    return detail[:1500]


def _parse_api_response(raw: bytes) -> dict[str, Any]:
    text = raw.decode("utf-8", errors="replace").strip()
    if "data:" in text:
        latest: dict[str, Any] | None = None
        for line in text.splitlines():
            if not line.startswith("data:"):
                continue
            payload = line[5:].strip()
            if not payload or payload == "[DONE]":
                continue
            try:
                event = json.loads(payload)
            except json.JSONDecodeError:
                continue
            if isinstance(event, dict):
                latest = event
        if latest is not None:
            if latest.get("url") and not latest.get("data"):
                latest["data"] = [{"url": latest["url"]}]
            return latest
    try:
        result = json.loads(text)
    except json.JSONDecodeError as exc:
        raise ImageGenError("Image API returned invalid JSON") from exc
    if not isinstance(result, dict):
        raise ImageGenError("Image API returned an invalid JSON object")
    if not result.get("data") and isinstance(result.get("results"), list):
        result["data"] = result["results"]
    if not result.get("data") and result.get("url"):
        result["data"] = [{"url": result["url"]}]
    if not result.get("data") and not (result.get("id") or result.get("task_id")):
        raise ImageGenError("Image API returned no image data")
    return result


def _post_image_request(
    endpoint: str,
    key: str,
    body: bytes,
    content_type: str,
    timeout: int,
) -> dict[str, Any]:
    request = urllib.request.Request(
        endpoint,
        data=body,
        headers={
            "Authorization": f"Bearer {key}",
            "Content-Type": content_type,
            "Accept": "application/json",
            "User-Agent": f"Matrixapi-imagegen-skill/{SKILL_VERSION}",
        },
        method="POST",
    )
    try:
        with urllib.request.urlopen(request, timeout=timeout) as response:
            raw = _read_limited(response, MAX_RESPONSE_BYTES)
    except urllib.error.HTTPError as exc:
        detail = _safe_http_detail(exc, key)
        raise ImageGenError(f"Image API returned HTTP {exc.code}: {detail}") from exc
    except (urllib.error.URLError, TimeoutError, OSError) as exc:
        raise ImageGenError(f"Image API request failed: {exc}") from exc
    return _parse_api_response(raw)


def _option_fields(
    quality: str = "",
    background: str = "",
    input_fidelity: str = "",
) -> dict[str, str]:
    fields: dict[str, str] = {}
    if quality:
        fields["quality"] = quality
    if background:
        fields["background"] = background
    if input_fidelity:
        fields["input_fidelity"] = input_fidelity
    return fields


def call_api(
    endpoint: str,
    key: str,
    model: str,
    prompt: str,
    size: str,
    count: int,
    timeout: int,
    options: dict[str, str] | None = None,
    aspect_ratio: str = "",
    image_urls: list[str] | None = None,
    async_mode: bool = False,
) -> dict[str, Any]:
    """Call the JSON generations endpoint."""
    payload: dict[str, Any] = {
        "model": model,
        "prompt": prompt,
        "size": size,
    }
    if count != 1:
        payload["n"] = count
    if options:
        payload.update(options)
    if aspect_ratio:
        payload["aspect_ratio"] = aspect_ratio
    if image_urls:
        payload["images"] = image_urls
    payload["async"] = async_mode
    return _post_image_request(
        endpoint,
        key,
        json.dumps(payload, ensure_ascii=False).encode("utf-8"),
        "application/json",
        timeout,
    )


def _safe_filename(path: Path) -> str:
    name = path.name.replace("\r", "").replace("\n", "")
    name = name.replace('"', "'")
    return name or "image"


def _input_image(path_value: str, label: str) -> tuple[str, str, bytes]:
    path = Path(path_value).expanduser()
    if not path.is_file():
        raise ImageGenError(f"{label} file does not exist: {path}")
    try:
        size = path.stat().st_size
    except OSError as exc:
        raise ImageGenError(f"Unable to inspect {label} file: {path}") from exc
    if size <= 0:
        raise ImageGenError(f"{label} file is empty: {path}")
    if size > MAX_IMAGE_BYTES:
        raise ImageGenError(f"{label} file exceeds the 50 MB safety limit: {path}")
    try:
        data = path.read_bytes()
    except OSError as exc:
        raise ImageGenError(f"Unable to read {label} file: {path}") from exc
    mime = _input_mime(data, path)
    return _safe_filename(path), mime, data


def _input_mime(data: bytes, path: Path) -> str:
    if data.startswith(b"\x89PNG\r\n\x1a\n"):
        return "image/png"
    if data.startswith(b"\xff\xd8\xff"):
        return "image/jpeg"
    if data.startswith(b"RIFF") and data[8:12] == b"WEBP":
        return "image/webp"
    if data.startswith((b"GIF87a", b"GIF89a")):
        return "image/gif"
    guessed, _ = mimetypes.guess_type(path.name)
    if guessed in SUPPORTED_IMAGE_MIME:
        return guessed
    raise ImageGenError(
        f"{path} is not a supported image; use PNG, JPEG, WEBP, or GIF"
    )


def _input_image_bytes(image_paths: list[str], mask_path: str | None = None) -> int:
    total = 0
    for path in image_paths + ([mask_path] if mask_path else []):
        if not path:
            continue
        total += len(_input_image(path, "Input image")[2])
    return total


def should_auto_async_local_edit(
    size: str,
    model: str,
    image_count: int,
    input_bytes: int,
    has_mask: bool,
) -> bool:
    if model not in SUPPORTED_MODELS or has_mask:
        return False
    width, height = (int(value) for value in size.split("x"))
    if max(width, height) <= EDIT_MAX_EDGE:
        return False
    return image_count >= AUTO_ASYNC_REFERENCE_COUNT or input_bytes >= AUTO_ASYNC_REFERENCE_BYTES


def _multipart_body(
    fields: Iterable[tuple[str, str]],
    files: Iterable[tuple[str, str, str, bytes]],
) -> tuple[bytes, str]:
    boundary = f"----api-imagegen-{uuid.uuid4().hex}"
    chunks: list[bytes] = []
    for name, value in fields:
        chunks.append(
            (
                f"--{boundary}\r\n"
                f'Content-Disposition: form-data; name="{name}"\r\n\r\n'
                f"{value}\r\n"
            ).encode("utf-8")
        )
    for name, filename, mime, data in files:
        chunks.append(
            (
                f"--{boundary}\r\n"
                f'Content-Disposition: form-data; name="{name}"; '
                f'filename="{filename}"\r\n'
                f"Content-Type: {mime}\r\n\r\n"
            ).encode("utf-8")
        )
        chunks.append(data)
        chunks.append(b"\r\n")
    chunks.append(f"--{boundary}--\r\n".encode("ascii"))
    return b"".join(chunks), f"multipart/form-data; boundary={boundary}"


def call_edit_api(
    endpoint: str,
    key: str,
    model: str,
    prompt: str,
    size: str,
    count: int,
    image_paths: list[str],
    mask_path: str | None,
    timeout: int,
    options: dict[str, str] | None = None,
) -> dict[str, Any]:
    if not image_paths:
        raise ImageGenError("At least one --image file is required for editing")
    if len(image_paths) > MAX_INPUT_IMAGES:
        raise ImageGenError(f"At most {MAX_INPUT_IMAGES} input images are supported")

    fields: list[tuple[str, str]] = [
        ("model", model),
        ("prompt", prompt),
        ("size", size),
        ("n", str(count)),
    ]
    if options:
        fields.extend(options.items())

    files: list[tuple[str, str, str, bytes]] = []
    for path in image_paths:
        filename, mime, data = _input_image(path, "Input image")
        files.append(("image", filename, mime, data))
    if mask_path:
        filename, mime, data = _input_image(mask_path, "Mask image")
        files.append(("mask", filename, mime, data))

    body, content_type = _multipart_body(fields, files)
    return _post_image_request(endpoint, key, body, content_type, timeout)


def _origin(url: str) -> tuple[str, str, int | None]:
    parsed = urllib.parse.urlparse(url)
    try:
        port = parsed.port
    except ValueError:
        port = None
    return parsed.scheme.lower(), (parsed.hostname or "").lower(), port


def _image_extension(data: bytes, content_type: str = "") -> str:
    if data.startswith(b"\x89PNG\r\n\x1a\n"):
        return ".png"
    if data.startswith(b"\xff\xd8\xff"):
        return ".jpg"
    if data.startswith(b"RIFF") and data[8:12] == b"WEBP":
        return ".webp"
    if data.startswith((b"GIF87a", b"GIF89a")):
        return ".gif"
    normalized = content_type.lower().split(";", 1)[0].strip()
    if normalized in SUPPORTED_IMAGE_MIME:
        return {
            "image/png": ".png",
            "image/jpeg": ".jpg",
            "image/webp": ".webp",
            "image/gif": ".gif",
        }[normalized]
    raise ImageGenError("The API returned data that is not a supported image")


def _image_metadata(data: bytes, content_type: str = "") -> dict[str, int | str]:
    """Read the actual dimensions and format from a supported raster image."""
    image_format = ""
    width = height = 0

    if data.startswith(b"\x89PNG\r\n\x1a\n") and len(data) >= 24:
        image_format = "PNG"
        width = int.from_bytes(data[16:20], "big")
        height = int.from_bytes(data[20:24], "big")
    elif data.startswith((b"GIF87a", b"GIF89a")) and len(data) >= 10:
        image_format = "GIF"
        width = int.from_bytes(data[6:8], "little")
        height = int.from_bytes(data[8:10], "little")
    elif data.startswith(b"RIFF") and data[8:12] == b"WEBP":
        image_format = "WEBP"
        chunk = data[12:16]
        if chunk == b"VP8X" and len(data) >= 30:
            width = int.from_bytes(data[24:27], "little") + 1
            height = int.from_bytes(data[27:30], "little") + 1
        elif chunk == b"VP8 " and len(data) >= 30 and data[23:26] == b"\x9d\x01\x2a":
            width = int.from_bytes(data[26:28], "little") & 0x3FFF
            height = int.from_bytes(data[28:30], "little") & 0x3FFF
        elif chunk == b"VP8L" and len(data) >= 25 and data[20] == 0x2F:
            bits = int.from_bytes(data[21:25], "little")
            width = (bits & 0x3FFF) + 1
            height = ((bits >> 14) & 0x3FFF) + 1
    elif data.startswith(b"\xff\xd8\xff"):
        image_format = "JPEG"
        offset = 2
        sof_markers = {
            0xC0, 0xC1, 0xC2, 0xC3, 0xC5, 0xC6, 0xC7,
            0xC9, 0xCA, 0xCB, 0xCD, 0xCE, 0xCF,
        }
        while offset + 9 <= len(data):
            if data[offset] != 0xFF:
                offset += 1
                continue
            while offset < len(data) and data[offset] == 0xFF:
                offset += 1
            if offset >= len(data):
                break
            marker = data[offset]
            offset += 1
            if marker in {0xD8, 0xD9} or 0xD0 <= marker <= 0xD7:
                continue
            if offset + 2 > len(data):
                break
            segment_length = int.from_bytes(data[offset:offset + 2], "big")
            if segment_length < 2 or offset + segment_length > len(data):
                break
            if marker in sof_markers and segment_length >= 7:
                height = int.from_bytes(data[offset + 3:offset + 5], "big")
                width = int.from_bytes(data[offset + 5:offset + 7], "big")
                break
            offset += segment_length

    if not image_format:
        _image_extension(data, content_type)
    if width <= 0 or height <= 0:
        raise ImageGenError("Unable to read the generated image dimensions")

    longest_edge = max(width, height)
    resolution = "4K" if longest_edge >= 3840 else "2K" if longest_edge >= 2048 else "1K"
    return {
        "width": width,
        "height": height,
        "format": image_format,
        "resolution": resolution,
    }


def _decode_data_url(url: str) -> tuple[bytes, str]:
    header, encoded = url.split(",", 1)
    try:
        return base64.b64decode(encoded, validate=True), header[5:].split(";", 1)[0]
    except (binascii.Error, ValueError) as exc:
        raise ImageGenError("Image API returned invalid base64 image data") from exc


def _download_image(url: str, endpoint: str, key: str, timeout: int) -> tuple[bytes, str]:
    if url.startswith("data:") and ";base64," in url:
        return _decode_data_url(url)

    parsed = urllib.parse.urlparse(url)
    if parsed.scheme not in {"http", "https"} or not parsed.hostname:
        raise ImageGenError("Image API returned an unsupported image URL")
    headers = {"User-Agent": f"Matrixapi-imagegen-skill/{SKILL_VERSION}"}
    if _origin(url) == _origin(endpoint):
        headers["Authorization"] = f"Bearer {key}"
    request = urllib.request.Request(url, headers=headers)
    try:
        with urllib.request.urlopen(request, timeout=timeout) as response:
            content_type = response.headers.get("Content-Type", "")
            return _read_limited(response, MAX_IMAGE_BYTES), content_type
    except (urllib.error.HTTPError, urllib.error.URLError, TimeoutError, OSError) as exc:
        raise ImageGenError(f"Unable to download the generated image: {exc}") from exc


def save_images(
    result: dict[str, Any], endpoint: str, key: str, output_dir: Path, timeout: int
) -> tuple[list[str], list[dict[str, int | str]]]:
    output_dir.mkdir(parents=True, exist_ok=True)
    stamp = time.strftime("%Y%m%d-%H%M%S")
    run_id = uuid.uuid4().hex[:8]
    paths: list[str] = []
    image_info: list[dict[str, int | str]] = []

    for index, item in enumerate(result["data"], start=1):
        if not isinstance(item, dict):
            raise ImageGenError("Image API returned an invalid image item")
        content_type = ""
        if item.get("b64_json"):
            try:
                data = base64.b64decode(item["b64_json"], validate=True)
            except (binascii.Error, ValueError, TypeError) as exc:
                raise ImageGenError("Image API returned invalid base64 image data") from exc
        elif item.get("url"):
            data, content_type = _download_image(
                str(item["url"]), endpoint, key, timeout
            )
        else:
            raise ImageGenError("Image item has neither url nor b64_json")

        if not data or len(data) > MAX_IMAGE_BYTES:
            raise ImageGenError("Generated image is empty or too large")
        suffix = _image_extension(data, content_type)
        metadata = _image_metadata(data, content_type)
        final_path = output_dir / f"image-{stamp}-{run_id}-{index}{suffix}"
        temp_path = final_path.with_suffix(final_path.suffix + ".part")
        temp_path.write_bytes(data)
        temp_path.replace(final_path)
        paths.append(str(final_path.resolve()))
        image_info.append(metadata)
    return paths, image_info


def preview_paths(paths: Iterable[str]) -> list[str]:
    """Return absolute paths normalized for the chat renderer's Markdown URLs."""
    return [Path(path).resolve().as_posix() for path in paths]


def _result_file(output_dir: Path, request_id: str) -> Path:
    return output_dir / f".result-{request_id}.json"


def _completion_marker(output_dir: Path, request_id: str) -> Path:
    return output_dir / f".completed-{request_id}.json"


def _ready_marker(output_dir: Path, request_id: str) -> Path:
    return output_dir / f".ready-{request_id}.json"


def _running_marker(output_dir: Path, request_id: str) -> Path:
    return output_dir / f".running-{request_id}.json"


def _write_sidecar(path: Path, payload: dict[str, Any]) -> None:
    temp_path = path.with_suffix(path.suffix + ".part")
    temp_path.write_text(
        json.dumps(payload, ensure_ascii=False), encoding="utf-8"
    )
    temp_path.replace(path)


def _status_endpoint(endpoint: str, task_id: str) -> str:
    parsed = urllib.parse.urlparse(endpoint)
    path = parsed.path
    marker = "/images/generations"
    if marker in path:
        path = path.split(marker, 1)[0] + f"/status/{urllib.parse.quote(task_id, safe='')}"
    else:
        path = path.rstrip("/") + f"/status/{urllib.parse.quote(task_id, safe='')}"
    return urllib.parse.urlunparse(parsed._replace(path=path, query="", fragment=""))


def _get_image_request(endpoint: str, key: str, timeout: int) -> dict[str, Any]:
    request = urllib.request.Request(
        endpoint,
        headers={"Authorization": f"Bearer {key}", "Accept": "application/json", "User-Agent": f"Matrixapi-imagegen-skill/{SKILL_VERSION}"},
        method="GET",
    )
    try:
        with urllib.request.urlopen(request, timeout=timeout) as response:
            return _parse_api_response(_read_limited(response, MAX_RESPONSE_BYTES))
    except urllib.error.HTTPError as exc:
        raise ImageGenError(f"Image status request failed with HTTP {exc.code}: {_safe_http_detail(exc, key)}") from exc
    except (urllib.error.URLError, TimeoutError, OSError) as exc:
        raise ImageGenError(f"Image status request failed: {exc}") from exc


def wait_for_task(result: dict[str, Any], endpoint: str, key: str, timeout: int) -> dict[str, Any]:
    if result.get("data"):
        return result
    task_id = str(result.get("id") or result.get("task_id") or "").strip()
    if not task_id:
        raise ImageGenError("Async image API response did not include a task id")
    deadline = time.monotonic() + timeout
    status_url = _status_endpoint(endpoint, task_id)
    while time.monotonic() < deadline:
        latest = _get_image_request(status_url, key, min(60, max(10, timeout)))
        status = str(latest.get("status") or "").lower()
        if status in {"succeeded", "completed"} or (latest.get("data") and not status):
            return latest
        if status in {"failed", "error", "cancelled"}:
            reason = latest.get("failure_reason") or latest.get("error") or status
            raise ImageGenError(f"Async image task failed: {reason}")
        time.sleep(3)
    raise ImageGenError(f"Image task timed out after {timeout} seconds: {task_id}")


def _hide_sidecar(path: Path) -> None:
    """Hide task sidecars in Windows Explorer without changing their paths."""
    if os.name != "nt":
        return
    try:
        import ctypes

        get_attributes = ctypes.windll.kernel32.GetFileAttributesW
        set_attributes = ctypes.windll.kernel32.SetFileAttributesW
        get_attributes.argtypes = [ctypes.c_wchar_p]
        get_attributes.restype = ctypes.c_uint32
        set_attributes.argtypes = [ctypes.c_wchar_p, ctypes.c_uint32]
        set_attributes.restype = ctypes.c_int
        attributes = get_attributes(str(path))
        if attributes == 0xFFFFFFFF:
            return
        set_attributes(str(path), attributes | 0x2)
    except (AttributeError, OSError):
        # The sidecar remains usable if the platform cannot set Explorer flags.
        return


def _load_ready_result(
    path: Path, request_id: str, execution_id: str, fingerprint: str = ""
) -> dict[str, Any]:
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        raise ImageGenError("The saved result for this task is not readable") from exc
    preview_files = payload.get("preview_files") if isinstance(payload, dict) else None
    if (
        not isinstance(payload, dict)
        or payload.get("ok") is not True
        or payload.get("request_id") != request_id
        or payload.get("execution_id") != execution_id
        or (fingerprint and payload.get("request_fingerprint") != fingerprint)
        or not isinstance(preview_files, list)
        or not preview_files
        or any(not isinstance(path_value, str) or not Path(path_value).is_file() for path_value in preview_files)
    ):
        raise ImageGenError("The saved result for this task is incomplete")
    return payload


def _load_running_execution(
    path: Path, request_id: str
) -> tuple[str, float] | None:
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
        execution_id = payload["execution_id"]
        expires_at = float(payload["expires_at"])
    except (KeyError, OSError, TypeError, ValueError, json.JSONDecodeError):
        return None
    if (
        payload.get("request_id") != request_id
        or not isinstance(execution_id, str)
        or not execution_id
    ):
        return None
    return execution_id, expires_at


def _reserve_request(
    output_dir: Path,
    request_id: str,
    allow_repeat: bool,
    timeout: int,
    fingerprint: str = "",
) -> tuple[Path | None, str, dict[str, Any] | None]:
    """Reserve a task before the API call and reuse an overlapping task's result."""
    output_dir.mkdir(parents=True, exist_ok=True)
    ready = _ready_marker(output_dir, request_id)
    running = _running_marker(output_dir, request_id)
    reservation_seconds = timeout * 2 + 60
    deadline = time.monotonic() + reservation_seconds
    observed_execution_id = ""

    while True:
        if observed_execution_id and ready.is_file():
            try:
                result = _load_ready_result(
                    ready, request_id, observed_execution_id, fingerprint
                )
            except ImageGenError:
                result = None
            if result is not None:
                return None, observed_execution_id, result

        # A ready file from an earlier execution never reserves the task ID.
        # Only a process that observed the currently active running marker may
        # reuse that execution's exact result.
        if observed_execution_id and not running.exists():
            raise ImageGenError(
                "The overlapping image request ended without a usable result"
            )

        execution_id = uuid.uuid4().hex
        try:
            descriptor = os.open(running, os.O_CREAT | os.O_EXCL | os.O_WRONLY)
        except FileExistsError:
            active = _load_running_execution(running, request_id)
            if active is not None and active[1] <= time.time():
                try:
                    running.unlink()
                except FileNotFoundError:
                    pass
                continue
            if active is not None:
                observed_execution_id = active[0]
            if time.monotonic() >= deadline:
                raise ImageGenError(
                    "This task ID is still running; continue waiting for the original command"
                )
            time.sleep(0.1)
            continue

        with os.fdopen(descriptor, "w", encoding="utf-8") as handle:
            json.dump(
                {
                    "request_id": request_id,
                    "execution_id": execution_id,
                    "skill_version": SKILL_VERSION,
                    "request_fingerprint": fingerprint,
                    "expires_at": time.time() + reservation_seconds,
                },
                handle,
            )
        try:
            _hide_sidecar(running)
        except Exception:
            pass
        return running, execution_id, None


def _release_request(running: Path) -> None:
    try:
        running.unlink()
    except FileNotFoundError:
        pass


def _refresh_request_reservation(
    running: Path, request_id: str, execution_id: str, timeout: int, fingerprint: str = ""
) -> None:
    """Keep a long multi-output task reserved while each image is processed."""
    _write_sidecar(
        running,
        {
            "request_id": request_id,
            "execution_id": execution_id,
            "skill_version": SKILL_VERSION,
            "request_fingerprint": fingerprint,
            "expires_at": time.time() + timeout * 2 + 60,
        },
    )
    _hide_sidecar(running)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--prompt")
    parser.add_argument(
        "--image",
        "--reference-image",
        dest="images",
        action="append",
        metavar="PATH",
        help="Local input/reference image; repeat for multiple images and enable edit mode",
    )
    parser.add_argument(
        "--mask",
        metavar="PATH",
        help="Optional local PNG/JPEG mask for the edit request",
    )
    parser.add_argument(
        "--expected-images",
        type=int,
        metavar="COUNT",
        help="Require exactly COUNT current-message input images before contacting the API",
    )
    parser.add_argument(
        "--mode",
        choices=("auto", "generate", "edit"),
        default="auto",
        help="Request mode; auto selects edit when --image is supplied",
    )
    parser.add_argument("--size", default="1024x1024")
    parser.add_argument("--aspect-ratio", default="")
    parser.add_argument("--n", type=int, default=1)
    parser.add_argument("--quality")
    parser.add_argument("--background")
    parser.add_argument("--input-fidelity")
    parser.add_argument("--out-dir", type=Path)
    parser.add_argument("--timeout", type=int, default=600)
    parser.add_argument("--async", dest="async_mode", action="store_true")
    parser.add_argument("--process-only", action="store_true")
    parser.add_argument("--output-size")
    parser.add_argument("--fit", choices=("cover", "contain", "fill", "inside", "outside"), default="cover")
    parser.add_argument("--position", default="center")
    parser.add_argument("--crop")
    parser.add_argument("--output-format", choices=("same", "png", "jpeg", "jpg", "webp", "avif"), default="same")
    parser.add_argument("--output-quality", type=int)
    parser.add_argument("--output-background")
    parser.add_argument(
        "--request-id",
        help="Caller-owned task identifier used to bind output to this request",
    )
    parser.add_argument(
        "--allow-repeat",
        action="store_true",
        help="Allow an explicit retry of a completed request ID",
    )
    parser.add_argument("--check-config", action="store_true")
    return parser.parse_args()


def main() -> int:
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8")
    args = parse_args()
    try:
        if args.process_only:
            image_paths = list(args.images or [])
            if not image_paths:
                raise ImageGenError("--process-only requires at least one --image file")
            if not (args.output_size or args.crop or args.output_format != "same" or args.output_quality is not None or args.output_background):
                raise ImageGenError("--process-only requires a local output or crop option")
            try:
                processed = process_many(
                    image_paths,
                    args.out_dir or (Path.home() / ".codex" / "generated_images" / "Matrixapi-imagegen" / "processed"),
                    output_size=args.output_size,
                    fit=args.fit,
                    position=args.position,
                    crop=args.crop,
                    output_format=args.output_format,
                    quality=args.output_quality or 90,
                    background_color=args.output_background,
                )
            except PostprocessError as exc:
                raise ImageGenError(str(exc)) from exc
            outputs = [item["output"] for item in processed]
            payload = {"ok": True, "event": "complete", "mode": "local-process", "skill_version": SKILL_VERSION, "count": len(outputs), "original_files": preview_paths(image_paths), "processed_files": preview_paths(outputs), "preview_files": preview_paths(outputs), "download_files": preview_paths(outputs), "result_ref": {"scope": "current-conversation", "files": preview_paths(outputs)}}
            print(json.dumps(payload, ensure_ascii=False), flush=True)
            return 0
        request_id = (args.request_id or uuid.uuid4().hex).strip()
        if not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9._-]{0,79}", request_id):
            raise ImageGenError(
                "Request ID must contain only letters, numbers, dots, underscores, or hyphens"
            )
        if args.n < 1:
            raise ImageGenError("Image count must be at least 1")
        if args.timeout < 10 or args.timeout > 600:
            raise ImageGenError("Timeout must be between 10 and 600 seconds")
        requested_size = validate_size(args.size)
        base_url, key, model, source = discover_credentials()
        generation_url = generation_endpoint(base_url)
        edit_url = edit_endpoint(base_url)
        if args.check_config:
            print(
                json.dumps(
                    {
                        "ok": True,
                        "credential_source": source,
                        "model": model,
                        "skill_version": SKILL_VERSION,
                        "supported_models": list(SUPPORTED_MODELS),
                        "supported_modes": ["generate", "edit"],
                    },
                    ensure_ascii=False,
                )
            )
            return 0

        raw_prompt = (args.prompt or "").strip()
        if not raw_prompt:
            raise ImageGenError("Prompt must not be empty")
        prompt, prompt_rewritten = sanitize_prompt(raw_prompt)
        prompt, prompt_compacted = compact_prompt(prompt)

        image_paths = list(args.images or [])
        if args.expected_images is not None:
            if args.expected_images < 1 or args.expected_images > MAX_INPUT_IMAGES:
                raise ImageGenError(
                    f"Expected image count must be between 1 and {MAX_INPUT_IMAGES}"
                )
            if len(image_paths) != args.expected_images:
                missing = max(args.expected_images - len(image_paths), 0)
                raise ImageGenError(
                    "Current-message attachment count mismatch: "
                    f"expected {args.expected_images}, received {len(image_paths)}, "
                    f"missing {missing}; no image request was sent"
                )
        if args.mode == "generate" and (image_paths or args.mask):
            raise ImageGenError("--mode generate cannot be combined with --image or --mask")
        if args.mode == "edit" and not image_paths:
            raise ImageGenError("--mode edit requires at least one --image file")
        if args.mask and not image_paths:
            raise ImageGenError("--mask requires at least one --image file")
        if len(image_paths) > MAX_INPUT_IMAGES:
            raise ImageGenError(f"At most {MAX_INPUT_IMAGES} input images are supported")

        mode = "edit" if image_paths else "generate"
        aspect_ratio = default_aspect_ratio(requested_size, args.aspect_ratio)
        size = edit_working_size(requested_size) if mode == "edit" else requested_size
        input_bytes = _input_image_bytes(image_paths, args.mask) if image_paths else 0
        auto_async = bool(
            image_paths
            and should_auto_async_local_edit(
                size, model, len(image_paths), input_bytes, bool(args.mask)
            )
        )
        async_mode = bool(args.async_mode or auto_async)
        fingerprint = request_fingerprint(
            prompt, model, size, mode, args.quality or "", image_paths, args.mask
        )
        output_dir = args.out_dir or (
            Path.home() / ".codex" / "generated_images" / "Matrixapi-imagegen"
        )
        ready = _ready_marker(output_dir, request_id)
        running, execution_id, existing_result = _reserve_request(
            output_dir, request_id, args.allow_repeat, args.timeout, fingerprint
        )
        if existing_result is not None:
            print(json.dumps(existing_result, ensure_ascii=False), flush=True)
            return 0
        options = _option_fields(args.quality, args.background, args.input_fidelity)
        if aspect_ratio:
            options["aspect_ratio"] = aspect_ratio
        if async_mode:
            options["async"] = "true"
        files: list[str] = []
        image_info: list[dict[str, int | str]] = []
        partial_error = ""
        failed_output = None
        for output_index in range(1, args.n + 1):
            _refresh_request_reservation(
                running, request_id, execution_id, args.timeout, fingerprint
            )
            try:
                if mode == "edit":
                    result = call_edit_api(
                        edit_url,
                        key,
                        model,
                        prompt,
                        size,
                        1,
                        image_paths,
                        args.mask,
                        args.timeout,
                        options,
                    )
                    if async_mode:
                        result = wait_for_task(result, generation_url, key, args.timeout)
                else:
                    result = call_api(
                        generation_url,
                        key,
                        model,
                        prompt,
                        size,
                        1,
                        args.timeout,
                        options,
                        aspect_ratio=aspect_ratio,
                        async_mode=async_mode,
                    )
                    if async_mode:
                        result = wait_for_task(result, generation_url, key, args.timeout)
                one_result = dict(result)
                one_result["data"] = result["data"][:1]
                saved_files, saved_info = save_images(
                    one_result,
                    edit_url if mode == "edit" else generation_url,
                    key,
                    output_dir,
                    args.timeout,
                )
            except ImageGenError as exc:
                if not files:
                    raise
                partial_error = str(exc)
                failed_output = output_index
                break

            files.extend(saved_files)
            image_info.extend(saved_info)
            if args.n > 1:
                print(
                    json.dumps(
                        {
                            "ok": True,
                            "event": "image_saved",
                            "complete": False,
                            "request_id": request_id,
                            "execution_id": execution_id,
                            "image_index": len(files),
                            "requested_count": args.n,
                            "preview_file": preview_paths(saved_files)[0],
                            "download_file": preview_paths(saved_files)[0],
                            "image_info": saved_info[0],
                            "result_ref": {
                                "scope": "current-conversation",
                                "request_id": request_id,
                                "execution_id": execution_id,
                                "request_fingerprint": fingerprint,
                                "files": preview_paths(saved_files),
                            },
                        },
                        ensure_ascii=False,
                    ),
                    flush=True,
                )
        original_files = preview_paths(files)
        processed_files = original_files.copy()
        postprocess_requested = bool(
            args.output_size
            or args.crop
            or args.output_format != "same"
            or args.output_quality is not None
            or args.output_background
        )
        if postprocess_requested and files:
            try:
                processed = process_many(
                    files,
                    args.out_dir or (output_dir / "processed"),
                    output_size=args.output_size,
                    fit=args.fit,
                    position=args.position,
                    crop=args.crop,
                    output_format=args.output_format,
                    quality=args.output_quality or 90,
                    background_color=args.output_background,
                )
                processed_files = preview_paths([item["output"] for item in processed])
            except PostprocessError as exc:
                partial_error = str(exc)
        preview_files = processed_files
        download_files = processed_files.copy()
        result_payload = {
            "ok": True,
            "event": "complete",
            "complete": not partial_error,
            "request_id": request_id,
            "execution_id": execution_id,
            "request_fingerprint": fingerprint,
            "mode": mode,
            "model": model,
            "skill_version": SKILL_VERSION,
            "quality": args.quality.strip() if args.quality else None,
            "count": len(files),
            "requested_count": args.n,
            "partial": bool(partial_error),
            "failed_output": failed_output,
            "error": partial_error or None,
            "size": size,
            "requested_size": requested_size,
            "edit_size": size if mode == "edit" else None,
            "resized_for_edit": mode == "edit" and size != requested_size,
            "input_images": len(image_paths),
            "input_bytes": input_bytes,
            "prompt_compacted": prompt_compacted,
            "prompt_rewritten": prompt_rewritten,
            "async": async_mode,
            "async_auto": auto_async,
            "mask": bool(args.mask),
            "files": files,
            "original_files": original_files,
            "processed_files": processed_files,
            "preview_files": preview_files,
            "download_files": download_files,
            "image_info": image_info,
            "result_ref": {
                "scope": "current-conversation",
                "request_id": request_id,
                "execution_id": execution_id,
                "request_fingerprint": fingerprint,
                "files": preview_files,
            },
        }

        # Write the marker before announcing success so retries remain bound to
        # this request. A marker failure must not hide a successfully saved
        # image from Codex, so the success JSON is always emitted next.
        try:
            _write_sidecar(ready, result_payload)
        except Exception:
            pass
        print(json.dumps(result_payload, ensure_ascii=False), flush=True)
        # Hiding is cosmetic and must never delay or suppress the success JSON.
        try:
            _hide_sidecar(ready)
        except Exception:
            pass
        return 0
    except ImageGenError as exc:
        print(
            json.dumps({"ok": False, "error": str(exc)}, ensure_ascii=False),
            file=sys.stderr,
        )
        return 1
    finally:
        if "running" in locals() and running is not None:
            _release_request(running)


if __name__ == "__main__":
    raise SystemExit(main())
