#!/usr/bin/env python3
"""Generate or edit images through the recipient's configured Images API."""

from __future__ import annotations

import argparse
import base64
import binascii
import json
import mimetypes
import os
from pathlib import Path
import re
import sqlite3
import subprocess
import sys
import time
from typing import Any, Iterable
import urllib.error
import urllib.parse
import urllib.request
import uuid

try:
    from postprocess import PostprocessError, parse_output_size, process_many
except ImportError:  # pragma: no cover - allows importing this file as a module
    from .postprocess import PostprocessError, parse_output_size, process_many


DEFAULT_MODEL = "gpt-image-2"
SKILL_NAME = "Matrixapi-imagegen"
SKILL_VERSION = "1.8.8"
DEFAULT_BASE_URL = "https://eos.manyuvip.com"
ALLOWED_BASE_HOST = "eos.manyuvip.com"
RESULT_HIDE_DELAY_MS = 10_000
MAX_RESPONSE_BYTES = 100 * 1024 * 1024
MAX_IMAGE_BYTES = 50 * 1024 * 1024
# Keep multipart uploads below the relay's 256 MiB request limit. The margin
# leaves room for multipart headers and prevents a proxy from cutting off a
# large request after the upstream task has already been billed.
MAX_MULTIPART_BODY_BYTES = 192 * 1024 * 1024
MAX_EDGE = 3840
MIN_PIXELS = 655_360
MAX_PIXELS = 14_745_600
MAX_INPUT_IMAGES = 16
# A large local edit is more reliable as a JSON async task. The relay stages
# local files as temporary HTTPS references before submitting upstream, so
# this changes only the response transport, never the source pixels or size.
AUTO_ASYNC_REFERENCE_COUNT = 6
AUTO_ASYNC_REFERENCE_BYTES = 48 * 1024 * 1024
PROMPT_MAX_CHARS = 1024
PROMPT_COMPACT_TARGET = 1000
# The pinned GPT Image 2 routes accept native 4K edits. Older relays can still
# opt into the legacy downscale through IMAGEGEN_LEGACY_EDIT_RESIZE.
EDIT_MAX_EDGE = 1792
QUALITY_VALUES = {"auto", "low", "medium", "high"}
ASPECT_RATIOS = {"auto", "1:1", "3:2", "2:3"}
SUPPORTED_IMAGE_MIME = {"image/png", "image/jpeg", "image/webp", "image/gif"}
MASK_SUPPORT_ENV = "IMAGEGEN_MASK_SUPPORT"


class ImageGenError(RuntimeError):
    pass


CONTENT_POLICY_MARKERS = (
    "copyright",
    "trademark",
    "safety",
    "moderation",
    "disallowed",
    "content policy",
    "policy violation",
    "content violation",
    "版权",
    "著作权",
    "商标",
    "安全策略",
    "内容审核",
    "内容违规",
)
ROUTE_MARKERS = (
    "model_not_found",
    "no available channel",
    "no usable channel",
    "distributor",
    "无可用渠道",
    "无可用模型",
    "模型不存在",
)


def _diagnose_upstream_failure(detail: str, status_code: int | None = None) -> tuple[str, str]:
    """Classify a relay/upstream error without pretending a generic 400 is a policy verdict."""
    normalized = (detail or "").lower()
    if any(marker.lower() in normalized for marker in CONTENT_POLICY_MARKERS):
        return (
            "content_policy",
            "模型明确拒绝了这次内容/版权/安全策略请求。这可能涉及版权角色、商标或其他内容限制，"
            "不是本地 Skill 的尺寸或文件错误；请改用原创描述，或让中转站提供模型原始审核原因。",
        )
    if any(marker.lower() in normalized for marker in ROUTE_MARKERS):
        return (
            "model_route",
            "中转站当前没有可用的模型渠道，或模型映射不可用；这不是版权提示。请检查渠道、模型名和分组配置。",
        )
    if status_code in {400, 422} and (
        "request failed" in normalized
        or "bad_response_status_code" in normalized
        or not normalized
    ):
        return (
            "upstream_rejection_unknown",
            "中转站把模型的失败响应包装成了泛化错误，未返回具体原因；仅凭这个 400 无法确认是否版权拦截。"
            "相同请求在不同尺寸或模型也失败时，更应先排查模型渠道/路由和中转站错误透传。",
        )
    if status_code is not None and status_code >= 500:
        return (
            "upstream_service",
            "模型服务或中转站暂时失败，未生成图片；请检查模型服务状态和渠道日志。",
        )
    return (
        "upstream_request",
        "模型请求未成功，但返回信息不足以判断是参数、渠道还是内容策略；请查看中转站的原始响应。",
    )


def _format_upstream_error(detail: str, status_code: int | None = None) -> str:
    category, explanation = _diagnose_upstream_failure(detail, status_code)
    status = f"HTTP {status_code}" if status_code is not None else "异步任务失败"
    raw = (detail or "未提供详细原因").strip()[:1000]
    return f"{status} [{category}] {explanation} 原始信息: {raw}"


def compact_prompt(prompt: str, limit: int = PROMPT_MAX_CHARS) -> tuple[str, bool]:
    """Keep an overlong prompt within the upstream limit without a retry."""
    normalized = re.sub(r"\s+", " ", prompt).strip()
    if len(normalized) <= limit:
        return normalized, False

    target = min(limit, PROMPT_COMPACT_TARGET)
    marker = "..."
    available = max(32, target - len(marker) - 1)
    head_budget = max(16, int(available * 0.72))
    tail_budget = max(16, available - head_budget)
    head = normalized[:head_budget].rstrip(" ,;:")
    tail = normalized[-tail_budget:].lstrip(" ,;:")
    compacted = f"{head}{marker} {tail}".strip()
    if len(compacted) > limit:
        compacted = compacted[:limit].rstrip()
    return compacted, True


def _environment_value(name: str) -> str:
    value = os.environ.get(name, "").strip()
    if value:
        return value
    if os.name == "nt":
        try:
            import winreg

            with winreg.OpenKey(winreg.HKEY_CURRENT_USER, "Environment") as key:
                value, _ = winreg.QueryValueEx(key, name)
            if isinstance(value, str):
                return value.strip()
        except (FileNotFoundError, OSError):
            pass
    return ""


def _skill_env_file_values() -> dict[str, str]:
    """Read installer-managed credentials without evaluating shell syntax."""
    try:
        path = Path.home() / ".codex" / "Matrixapi-imagegen.env"
    except RuntimeError:
        return {}
    if not path.is_file():
        return {}
    try:
        lines = path.read_text(encoding="utf-8").splitlines()
    except OSError:
        return {}
    values: dict[str, str] = {}
    allowed = {"IMAGEGEN_API_KEY", "IMAGEGEN_MODEL"}
    for line in lines:
        stripped = line.strip()
        if not stripped or stripped.startswith("#") or "=" not in stripped:
            continue
        name, value = stripped.split("=", 1)
        name = name.strip()
        if name in allowed:
            values[name] = value.strip().strip('"').strip("'")
    return values


def mask_support_enabled(model: str) -> bool:
    """Return whether a model's local mask path was explicitly enabled."""
    if model not in {"gpt-image-2", "gpt-image-2-pro"}:
        return True
    return _environment_value(MASK_SUPPORT_ENV).lower() in {"1", "true", "yes"}


def _user_environment_value(name: str) -> str:
    if os.name != "nt":
        return ""
    try:
        import winreg

        with winreg.OpenKey(winreg.HKEY_CURRENT_USER, "Environment") as key:
            value, _ = winreg.QueryValueEx(key, name)
        return value.strip() if isinstance(value, str) else ""
    except (FileNotFoundError, OSError):
        return ""


def _nested_strings(value: Any, key_name: str) -> list[str]:
    found: list[str] = []
    if isinstance(value, dict):
        for key, child in value.items():
            if key == key_name and isinstance(child, str):
                found.append(child.strip())
            else:
                found.extend(_nested_strings(child, key_name))
    elif isinstance(value, list):
        for child in value:
            found.extend(_nested_strings(child, key_name))
    return [item for item in found if item]


def _provider_values(raw: str) -> tuple[str, str]:
    try:
        settings = json.loads(raw)
    except (json.JSONDecodeError, TypeError):
        return "", ""
    if not isinstance(settings, dict):
        return "", ""

    config = settings.get("config", {})
    urls = _nested_strings(config, "base_url")
    if isinstance(config, str):
        urls.extend(re.findall(r"base_url\s*=\s*[\"']([^\"']+)[\"']", config))

    auth = settings.get("auth", {})
    if isinstance(auth, str):
        try:
            auth = json.loads(auth)
        except json.JSONDecodeError:
            match = re.search(
                r"OPENAI_API_KEY\s*[=:]\s*[\"']?([^\s\"']+)", auth
            )
            auth = {"OPENAI_API_KEY": match.group(1)} if match else {}
    keys = _nested_strings(auth, "OPENAI_API_KEY")
    return (urls[0].strip() if urls else "", keys[0].strip() if keys else "")


def _discover_current_cc_switch_provider() -> tuple[str, str, str] | None:
    db_path = Path.home() / ".cc-switch" / "cc-switch.db"
    if not db_path.is_file():
        return None

    try:
        with sqlite3.connect(f"file:{db_path.as_posix()}?mode=ro", uri=True) as db:
            row = db.execute(
                "SELECT settings_config FROM providers "
                "WHERE app_type = 'codex' AND is_current = 1 LIMIT 1"
            ).fetchone()
    except (sqlite3.Error, OSError) as exc:
        raise ImageGenError("Unable to read the current CC Switch configuration") from exc

    if not row:
        return None
    base_url, key = _provider_values(row[0] or "")
    if base_url and key:
        return base_url, key, "CC Switch current Codex provider"
    return None


def _paired_environment(
    prefix: str, default_base_url: str = ""
) -> tuple[str, str] | None:
    base_url = _environment_value(f"{prefix}_BASE_URL")
    key = _environment_value(f"{prefix}_API_KEY")
    if not base_url and key and default_base_url:
        base_url = default_base_url
    if bool(base_url) != bool(key):
        raise ImageGenError(
            f"{prefix}_BASE_URL and {prefix}_API_KEY must be configured together"
        )
    return (base_url, key) if base_url and key else None


def discover_credentials() -> tuple[str, str, str, str]:
    skill_env = _skill_env_file_values()
    imagegen_key = _environment_value("IMAGEGEN_API_KEY") or skill_env.get(
        "IMAGEGEN_API_KEY", ""
    )
    if imagegen_key:
        base_url, key = DEFAULT_BASE_URL, imagegen_key
        source = "environment"
    else:
        configured = _paired_environment("OPENAI")
        if configured:
            base_url, key = configured
            source = "environment"
        else:
            current = _discover_current_cc_switch_provider()
            if not current:
                raise ImageGenError(
                    "No image API configuration found. Set IMAGEGEN_API_KEY, "
                    "set OPENAI_BASE_URL and OPENAI_API_KEY for the fixed relay, or "
                    "select a compatible Codex provider in CC Switch"
                )
            base_url, key, source = current

    # A persistent user-level model setting should win over a stale process
    # environment inherited by a long-lived desktop session.
    model = (
        _user_environment_value("IMAGEGEN_MODEL")
        or _environment_value("IMAGEGEN_MODEL")
        or skill_env.get("IMAGEGEN_MODEL", "")
        or DEFAULT_MODEL
    )
    return base_url, key, model, source


def _validate_base_url(base_url: str) -> tuple[urllib.parse.ParseResult, str]:
    try:
        parsed = urllib.parse.urlparse(base_url.strip())
        port = parsed.port
    except ValueError as exc:
        raise ImageGenError("The image API base URL is invalid") from exc
    if parsed.scheme not in {"http", "https"} or not parsed.hostname:
        raise ImageGenError("The image API base URL must be an HTTP or HTTPS URL")
    if parsed.scheme == "http" and parsed.hostname not in {"localhost", "127.0.0.1", "::1"}:
        raise ImageGenError("Non-local image API connections must use HTTPS")
    if parsed.username or parsed.password:
        raise ImageGenError("The image API base URL must not contain credentials")
    normalized_host = (parsed.hostname or "").rstrip(".").lower()
    if normalized_host != ALLOWED_BASE_HOST:
        raise ImageGenError(
            f"This Skill only supports the configured image relay: {ALLOWED_BASE_HOST}"
        )

    netloc = parsed.hostname
    if ":" in netloc and not netloc.startswith("["):
        netloc = f"[{netloc}]"
    if port is not None:
        netloc = f"{netloc}:{port}"
    return parsed._replace(netloc=netloc), parsed.path.rstrip("/")


def image_endpoint(base_url: str, operation: str) -> str:
    if operation not in {"generations", "edits"}:
        raise ImageGenError("Unsupported image operation")
    parsed, path = _validate_base_url(base_url)
    operation_path = f"/images/{operation}"
    if path.endswith(operation_path):
        endpoint_path = path
    elif path.endswith("/v1"):
        endpoint_path = path + operation_path
    else:
        endpoint_path = path + "/v1" + operation_path
    return urllib.parse.urlunparse(
        parsed._replace(path=endpoint_path, params="", query="", fragment="")
    )


def generation_endpoint(base_url: str) -> str:
    """Return the generations endpoint (kept for callers of the original script)."""
    return image_endpoint(base_url, "generations")


def edit_endpoint(base_url: str) -> str:
    return image_endpoint(base_url, "edits")


def validate_size(size: str) -> str:
    match = re.fullmatch(r"([1-9]\d*)x([1-9]\d*)", size.strip().lower())
    if not match:
        raise ImageGenError("Size must use WIDTHxHEIGHT, for example 1024x1024")
    width, height = int(match.group(1)), int(match.group(2))
    if width > MAX_EDGE or height > MAX_EDGE:
        raise ImageGenError("Image size must not exceed 3840px on either edge")
    if width % 16 or height % 16:
        raise ImageGenError("Image width and height must both be multiples of 16px")
    long_edge, short_edge = max(width, height), min(width, height)
    if long_edge > short_edge * 3:
        raise ImageGenError("Long edge to short edge ratio must not exceed 3:1")
    pixels = width * height
    if pixels < MIN_PIXELS or pixels > MAX_PIXELS:
        raise ImageGenError(
            f"Total pixels must be between {MIN_PIXELS:,} and {MAX_PIXELS:,}"
        )
    return f"{width}x{height}"


SIZE_ALIASES = {"1K", "2K", "4K"}


def normalize_size(size: str) -> str:
    normalized = size.strip().upper()
    if normalized in SIZE_ALIASES:
        return normalized
    return validate_size(normalized)


def legacy_pixel_size(size: str, aspect_ratio: str) -> str:
    """Map upstream size aliases to a multipart relay's pixel-size format."""
    if size not in SIZE_ALIASES:
        return validate_size(size)
    dimensions = {
        "1K": {"auto": "1024x1024", "1:1": "1024x1024", "3:2": "1536x1024", "2:3": "1024x1536"},
        "2K": {"auto": "2048x2048", "1:1": "2048x2048", "3:2": "2048x1360", "2:3": "1360x2048"},
        "4K": {"auto": "3840x2160", "1:1": "3840x3840", "3:2": "3840x2560", "2:3": "2560x3840"},
    }
    return validate_size(dimensions[size][aspect_ratio])


def validate_quality(quality: str) -> str:
    normalized = quality.strip().lower()
    if normalized not in QUALITY_VALUES:
        choices = ", ".join(sorted(QUALITY_VALUES))
        raise ImageGenError(f"Quality must be one of: {choices}")
    return normalized


def validate_aspect_ratio(aspect_ratio: str) -> str:
    normalized = aspect_ratio.strip().lower()
    if normalized not in ASPECT_RATIOS:
        choices = ", ".join(sorted(ASPECT_RATIOS))
        raise ImageGenError(f"Aspect ratio must be one of: {choices}")
    return normalized


def _dimensions_from_image_bytes(data: bytes, mime: str, label: str) -> tuple[int, int]:
    """Read dimensions from supported image headers without requiring Pillow."""
    width = height = 0
    if mime == "image/png" and len(data) >= 24 and data[:8] == b"\x89PNG\r\n\x1a\n":
        width = int.from_bytes(data[16:20], "big")
        height = int.from_bytes(data[20:24], "big")
    elif mime == "image/gif" and len(data) >= 10 and data[:6] in {b"GIF87a", b"GIF89a"}:
        width = int.from_bytes(data[6:8], "little")
        height = int.from_bytes(data[8:10], "little")
    elif mime == "image/webp" and len(data) >= 30 and data[:4] == b"RIFF" and data[8:12] == b"WEBP":
        offset = 12
        while offset + 8 <= len(data):
            chunk = data[offset : offset + 4]
            chunk_size = int.from_bytes(data[offset + 4 : offset + 8], "little")
            start = offset + 8
            end = start + chunk_size
            if end > len(data):
                break
            if chunk == b"VP8X" and chunk_size >= 10:
                width = 1 + int.from_bytes(data[start + 4 : start + 7], "little")
                height = 1 + int.from_bytes(data[start + 7 : start + 10], "little")
                break
            if chunk == b"VP8L" and chunk_size >= 5 and data[start] == 0x2F:
                bits = data[start + 1 : start + 5]
                width = 1 + (bits[0] | ((bits[1] & 0x3F) << 8))
                height = 1 + ((bits[1] >> 6) | (bits[2] << 2) | ((bits[3] & 0x0F) << 10))
                break
            if chunk == b"VP8 " and chunk_size >= 10:
                frame = data.find(b"\x9d\x01\x2a", start, end)
                if frame >= 0 and frame + 7 <= end:
                    width = int.from_bytes(data[frame + 3 : frame + 5], "little") & 0x3FFF
                    height = int.from_bytes(data[frame + 5 : frame + 7], "little") & 0x3FFF
                    break
            offset = end + (chunk_size & 1)
    elif mime == "image/jpeg" and len(data) >= 4 and data[:2] == b"\xff\xd8":
        offset = 2
        sof_markers = {
            *range(0xC0, 0xC4),
            *range(0xC5, 0xC8),
            *range(0xC9, 0xCC),
            *range(0xCD, 0xD0),
        }
        while offset + 3 < len(data):
            if data[offset] != 0xFF:
                offset += 1
                continue
            while offset < len(data) and data[offset] == 0xFF:
                offset += 1
            if offset >= len(data):
                break
            marker = data[offset]
            offset += 1
            if marker in {0xD8, 0xD9} or 0xD0 <= marker <= 0xD7:
                continue
            if offset + 2 > len(data):
                break
            segment_length = int.from_bytes(data[offset : offset + 2], "big")
            if segment_length < 2 or offset + segment_length > len(data):
                break
            if marker in sof_markers and segment_length >= 7:
                height = int.from_bytes(data[offset + 3 : offset + 5], "big")
                width = int.from_bytes(data[offset + 5 : offset + 7], "big")
                break
            offset += segment_length

    if width <= 0 or height <= 0:
        raise ImageGenError(f"无法读取{label}的宽高；请提供有效的 PNG、JPEG、WEBP 或 GIF 图片")
    return width, height


def image_dimensions(path_value: str, label: str = "Input image") -> tuple[int, int]:
    """Validate a local image and return its pixel dimensions."""
    _, mime, data = _input_image(path_value, label)
    return _dimensions_from_image_bytes(data, mime, label)


def infer_image_aspect_ratio(image_paths: list[str]) -> str:
    """Choose the closest supported model ratio from the first input image."""
    if not image_paths:
        raise ImageGenError("无法从空的输入图片列表推断比例")
    width, height = image_dimensions(image_paths[0])
    actual = width / height
    candidates = {"1:1": 1.0, "3:2": 1.5, "2:3": 2 / 3}
    return min(candidates, key=lambda ratio: abs(actual - candidates[ratio]))


def resolve_aspect_ratio(aspect_ratio: str, image_paths: list[str] | None = None) -> tuple[str, str]:
    """Resolve auto ratio and report whether it came from the input image."""
    normalized = validate_aspect_ratio(aspect_ratio)
    if normalized != "auto":
        return normalized, "user"
    if image_paths:
        return infer_image_aspect_ratio(image_paths), "input_image"
    return normalized, "model_default"


def edit_working_size(size: str, model: str) -> str:
    """Return the edit size, preserving native GPT Image 2 tiers by default."""
    if model in {"gpt-image-2", "gpt-image-2-pro"} and not _environment_value(
        "IMAGEGEN_LEGACY_EDIT_RESIZE"
    ).lower() in {"1", "true", "yes"}:
        return size

    width, height = (int(value) for value in size.split("x"))
    long_edge = max(width, height)
    if long_edge <= EDIT_MAX_EDGE:
        return size

    scale = EDIT_MAX_EDGE / long_edge
    working_width = max(16, int(width * scale) // 16 * 16)
    working_height = max(16, int(height * scale) // 16 * 16)

    # Rounding down can make a source ratio that was exactly 3:1 exceed the
    # provider's ratio limit by one block; trim the long edge if necessary.
    while max(working_width, working_height) > 3 * min(working_width, working_height):
        if working_width >= working_height:
            working_width -= 16
        else:
            working_height -= 16

    return validate_size(f"{working_width}x{working_height}")


def should_auto_async_local_edit(
    size: str,
    model: str,
    image_count: int,
    input_bytes: int,
    has_mask: bool,
) -> bool:
    """Select async only for local GPT Image 2 edits likely to outlive sync."""
    if model not in {"gpt-image-2", "gpt-image-2-pro"} or has_mask:
        return False
    width, height = (int(value) for value in size.split("x"))
    if max(width, height) <= EDIT_MAX_EDGE:
        return False
    return (
        image_count >= AUTO_ASYNC_REFERENCE_COUNT
        or input_bytes >= AUTO_ASYNC_REFERENCE_BYTES
    )


def _read_limited(response: Any, limit: int) -> bytes:
    data = response.read(limit + 1)
    if len(data) > limit:
        raise ImageGenError("The API response exceeded the local safety limit")
    return data


def _safe_http_detail(exc: urllib.error.HTTPError, key: str) -> str:
    detail = exc.read(8192).decode("utf-8", errors="replace")
    if key:
        detail = detail.replace(key, "[redacted]")
    return detail[:1500]


def _parse_api_response(raw: bytes) -> dict[str, Any]:
    text = raw.decode("utf-8", errors="replace").strip()
    if "data:" in text:
        last_event: dict[str, Any] | None = None
        for line in text.splitlines():
            if not line.startswith("data:"):
                continue
            payload = line[5:].strip()
            if not payload or payload == "[DONE]":
                continue
            try:
                event = json.loads(payload)
            except json.JSONDecodeError:
                continue
            if isinstance(event, dict):
                last_event = event
        if last_event:
            if last_event.get("url") and not last_event.get("data"):
                last_event["data"] = [{"url": last_event["url"]}]
            return last_event
    try:
        result = json.loads(text)
    except json.JSONDecodeError as exc:
        raise ImageGenError("Image API returned invalid JSON") from exc
    if not isinstance(result, dict):
        raise ImageGenError("Image API returned an invalid JSON object")
    if not result.get("data") and isinstance(result.get("results"), list):
        result["data"] = result["results"]
    if not result.get("data") and result.get("url"):
        result["data"] = [{"url": result["url"]}]
    return result


def _post_image_request(
    endpoint: str,
    key: str,
    body: bytes,
    content_type: str,
    timeout: int,
) -> dict[str, Any]:
    request = urllib.request.Request(
        endpoint,
        data=body,
        headers={
            "Authorization": f"Bearer {key}",
            "Content-Type": content_type,
            "Accept": "application/json",
            "User-Agent": f"Matrixapi-imagegen-skill/{SKILL_VERSION}",
        },
        method="POST",
    )
    try:
        with urllib.request.urlopen(request, timeout=timeout) as response:
            raw = _read_limited(response, MAX_RESPONSE_BYTES)
    except urllib.error.HTTPError as exc:
        detail = _safe_http_detail(exc, key)
        raise ImageGenError(_format_upstream_error(detail, exc.code)) from exc
    except (urllib.error.URLError, TimeoutError, OSError) as exc:
        raise ImageGenError(f"Image API request failed: {exc}") from exc
    return _parse_api_response(raw)


def _option_fields(
    quality: str = "",
    background: str = "",
    input_fidelity: str = "",
) -> dict[str, str]:
    fields: dict[str, str] = {}
    if quality:
        fields["quality"] = quality
    if background:
        fields["background"] = background
    if input_fidelity:
        fields["input_fidelity"] = input_fidelity
    return fields


def call_api(
    endpoint: str,
    key: str,
    model: str,
    prompt: str,
    size: str,
    count: int,
    timeout: int,
    options: dict[str, Any] | None = None,
    aspect_ratio: str = "",
    image_urls: list[str] | None = None,
    stream: bool = False,
    async_mode: bool = False,
    webhook: str = "",
    metadata: dict[str, Any] | None = None,
) -> dict[str, Any]:
    """Call the JSON generations endpoint."""
    payload: dict[str, Any] = {
        "model": model,
        "prompt": prompt,
        "size": size,
    }
    if count != 1:
        payload["n"] = count
    if options:
        payload.update(options)
    if aspect_ratio:
        payload["aspect_ratio"] = aspect_ratio
    if image_urls:
        payload["images"] = image_urls
    payload["stream"] = stream
    payload["async"] = async_mode
    if webhook:
        payload["webhook"] = webhook
    if metadata:
        payload["metadata"] = metadata
    return _post_image_request(
        endpoint,
        key,
        json.dumps(payload, ensure_ascii=False).encode("utf-8"),
        "application/json",
        timeout,
    )


def _status_endpoint(endpoint: str, task_id: str) -> str:
    parsed = urllib.parse.urlparse(endpoint)
    path = parsed.path
    marker = "/images/generations"
    if marker in path:
        path = path.split(marker, 1)[0] + f"/status/{urllib.parse.quote(task_id, safe='')}"
    else:
        path = path.rstrip("/") + f"/status/{urllib.parse.quote(task_id, safe='')}"
    return urllib.parse.urlunparse(parsed._replace(path=path, query="", fragment=""))


def _get_image_request(endpoint: str, key: str, timeout: int) -> dict[str, Any]:
    request = urllib.request.Request(
        endpoint,
        headers={
            "Authorization": f"Bearer {key}",
            "Accept": "application/json",
            "User-Agent": f"Matrixapi-imagegen-skill/{SKILL_VERSION}",
        },
        method="GET",
    )
    try:
        with urllib.request.urlopen(request, timeout=timeout) as response:
            return _parse_api_response(_read_limited(response, MAX_RESPONSE_BYTES))
    except urllib.error.HTTPError as exc:
        detail = _safe_http_detail(exc, key)
        raise ImageGenError(_format_upstream_error(detail, exc.code)) from exc
    except (urllib.error.URLError, TimeoutError, OSError) as exc:
        raise ImageGenError(f"Image status request failed: {exc}") from exc


def wait_for_task(
    result: dict[str, Any], endpoint: str, key: str, timeout: int
) -> dict[str, Any]:
    if result.get("data"):
        return result
    task_id = str(result.get("id") or result.get("task_id") or "").strip()
    if not task_id:
        raise ImageGenError("Async image API response did not include a task id")
    deadline = time.monotonic() + timeout
    status_url = _status_endpoint(endpoint, task_id)
    latest = result
    while time.monotonic() < deadline:
        latest = _get_image_request(status_url, key, min(60, max(10, timeout)))
        status = str(latest.get("status") or "").lower()
        if status in {"succeeded", "completed"} or (latest.get("data") and not status):
            return latest
        if status in {"failed", "error", "cancelled"}:
            reason = latest.get("failure_reason") or latest.get("error") or status
            reason_text = (
                json.dumps(reason, ensure_ascii=False)
                if isinstance(reason, (dict, list))
                else str(reason)
            )
            raise ImageGenError(_format_upstream_error(reason_text))
        # Results are delivered as soon as the relay reports completion. A
        # one-second interval avoids the old multi-second handoff delay while
        # keeping a single status request in flight.
        time.sleep(1)
    raise ImageGenError(f"Image task timed out after {timeout} seconds: {task_id}")


def _safe_filename(path: Path) -> str:
    name = path.name.replace("\r", "").replace("\n", "")
    name = name.replace('"', "'")
    return name or "image"


def _input_image(path_value: str, label: str) -> tuple[str, str, bytes]:
    path = Path(path_value).expanduser()
    if not path.is_file():
        raise ImageGenError(f"{label} file does not exist: {path}")
    try:
        size = path.stat().st_size
    except OSError as exc:
        raise ImageGenError(f"Unable to inspect {label} file: {path}") from exc
    if size <= 0:
        raise ImageGenError(f"{label} file is empty: {path}")
    if size > MAX_IMAGE_BYTES:
        raise ImageGenError(f"{label} file exceeds the 50 MB safety limit: {path}")
    try:
        data = path.read_bytes()
    except OSError as exc:
        raise ImageGenError(f"Unable to read {label} file: {path}") from exc
    mime = _input_mime(data, path)
    return _safe_filename(path), mime, data


def _input_image_bytes(paths: Iterable[str], mask_path: str | None = None) -> int:
    """Validate local file sizes before building or sending multipart data."""
    total = 0
    labelled_paths = [(path, "Input image") for path in paths]
    if mask_path:
        labelled_paths.append((mask_path, "Mask image"))
    for path_value, label in labelled_paths:
        path = Path(path_value).expanduser()
        if not path.is_file():
            raise ImageGenError(f"{label} file does not exist: {path}")
        try:
            size = path.stat().st_size
        except OSError as exc:
            raise ImageGenError(f"Unable to inspect {label} file: {path}") from exc
        if size <= 0:
            raise ImageGenError(f"{label} file is empty: {path}")
        if size > MAX_IMAGE_BYTES:
            raise ImageGenError(f"{label} file exceeds the 50 MB safety limit: {path}")
        total += size
    return total


def _input_mime(data: bytes, path: Path) -> str:
    if data.startswith(b"\x89PNG\r\n\x1a\n"):
        return "image/png"
    if data.startswith(b"\xff\xd8\xff"):
        return "image/jpeg"
    if data.startswith(b"RIFF") and data[8:12] == b"WEBP":
        return "image/webp"
    if data.startswith((b"GIF87a", b"GIF89a")):
        return "image/gif"
    guessed, _ = mimetypes.guess_type(path.name)
    if guessed in SUPPORTED_IMAGE_MIME:
        return guessed
    raise ImageGenError(
        f"{path} is not a supported image; use PNG, JPEG, WEBP, or GIF"
    )


def _multipart_body(
    fields: Iterable[tuple[str, str]],
    files: Iterable[tuple[str, str, str, bytes]],
) -> tuple[bytes, str]:
    boundary = f"----Matrixapi-imagegen-{uuid.uuid4().hex}"
    chunks: list[bytes] = []
    for name, value in fields:
        chunks.append(
            (
                f"--{boundary}\r\n"
                f'Content-Disposition: form-data; name="{name}"\r\n\r\n'
                f"{value}\r\n"
            ).encode("utf-8")
        )
    for name, filename, mime, data in files:
        chunks.append(
            (
                f"--{boundary}\r\n"
                f'Content-Disposition: form-data; name="{name}"; '
                f'filename="{filename}"\r\n'
                f"Content-Type: {mime}\r\n\r\n"
            ).encode("utf-8")
        )
        chunks.append(data)
        chunks.append(b"\r\n")
    chunks.append(f"--{boundary}--\r\n".encode("ascii"))
    return b"".join(chunks), f"multipart/form-data; boundary={boundary}"


def call_edit_api(
    endpoint: str,
    key: str,
    model: str,
    prompt: str,
    size: str,
    count: int,
    image_paths: list[str],
    mask_path: str | None,
    timeout: int,
    options: dict[str, str] | None = None,
) -> dict[str, Any]:
    if not image_paths:
        raise ImageGenError("At least one --image file is required for editing")
    if len(image_paths) > MAX_INPUT_IMAGES:
        raise ImageGenError(f"At most {MAX_INPUT_IMAGES} input images are supported")
    total_input_bytes = _input_image_bytes(image_paths, mask_path)
    if total_input_bytes > MAX_MULTIPART_BODY_BYTES:
        limit_mib = MAX_MULTIPART_BODY_BYTES // (1024 * 1024)
        actual_mib = total_input_bytes / (1024 * 1024)
        raise ImageGenError(
            f"Combined input images are too large for one upload ({actual_mib:.1f} MiB; "
            f"limit {limit_mib} MiB). Remove unrelated references or submit a smaller set; "
            "the images were not sent and no task was charged."
        )

    fields: list[tuple[str, str]] = [
        ("model", model),
        ("prompt", prompt),
        ("size", size),
    ]
    # The pinned GPT Image 2 contract does not guarantee the generic `n`
    # parameter. A single edit is the normal skill path, so omit n=1 even
    # before the relay's multipart-to-JSON conversion. Other image models keep
    # the legacy multipart count behavior for compatibility.
    if count != 1 and model not in {"gpt-image-2", "gpt-image-2-pro"}:
        fields.append(("n", str(count)))
    if options:
        fields.extend(options.items())

    files: list[tuple[str, str, str, bytes]] = []
    for path in image_paths:
        filename, mime, data = _input_image(path, "Input image")
        files.append(("image", filename, mime, data))
    if mask_path:
        filename, mime, data = _input_image(mask_path, "Mask image")
        files.append(("mask", filename, mime, data))

    body, content_type = _multipart_body(fields, files)
    return _post_image_request(endpoint, key, body, content_type, timeout)


def _origin(url: str) -> tuple[str, str, int | None]:
    parsed = urllib.parse.urlparse(url)
    try:
        port = parsed.port
    except ValueError:
        port = None
    return parsed.scheme.lower(), (parsed.hostname or "").lower(), port


def _image_extension(data: bytes, content_type: str = "") -> str:
    if data.startswith(b"\x89PNG\r\n\x1a\n"):
        return ".png"
    if data.startswith(b"\xff\xd8\xff"):
        return ".jpg"
    if data.startswith(b"RIFF") and data[8:12] == b"WEBP":
        return ".webp"
    if data.startswith((b"GIF87a", b"GIF89a")):
        return ".gif"
    normalized = content_type.lower().split(";", 1)[0].strip()
    if normalized in SUPPORTED_IMAGE_MIME:
        return {
            "image/png": ".png",
            "image/jpeg": ".jpg",
            "image/webp": ".webp",
            "image/gif": ".gif",
        }[normalized]
    raise ImageGenError("The API returned data that is not a supported image")


def _decode_data_url(url: str) -> tuple[bytes, str]:
    header, encoded = url.split(",", 1)
    try:
        return base64.b64decode(encoded, validate=True), header[5:].split(";", 1)[0]
    except (binascii.Error, ValueError) as exc:
        raise ImageGenError("Image API returned invalid base64 image data") from exc


def _download_image(url: str, endpoint: str, key: str, timeout: int) -> tuple[bytes, str]:
    if url.startswith("data:") and ";base64," in url:
        return _decode_data_url(url)

    parsed = urllib.parse.urlparse(url)
    if parsed.scheme not in {"http", "https"} or not parsed.hostname:
        raise ImageGenError("Image API returned an unsupported image URL")
    headers = {"User-Agent": f"Matrixapi-imagegen-skill/{SKILL_VERSION}"}
    if _origin(url) == _origin(endpoint):
        headers["Authorization"] = f"Bearer {key}"
    request = urllib.request.Request(url, headers=headers)
    try:
        with urllib.request.urlopen(request, timeout=timeout) as response:
            content_type = response.headers.get("Content-Type", "")
            return _read_limited(response, MAX_IMAGE_BYTES), content_type
    except (urllib.error.HTTPError, urllib.error.URLError, TimeoutError, OSError) as exc:
        raise ImageGenError(f"Unable to download the generated image: {exc}") from exc


def save_images(
    result: dict[str, Any], endpoint: str, key: str, output_dir: Path, timeout: int
) -> list[str]:
    output_dir.mkdir(parents=True, exist_ok=True)
    stamp = time.strftime("%Y%m%d-%H%M%S")
    run_id = uuid.uuid4().hex[:8]
    paths: list[str] = []

    items = result.get("data") or result.get("results")
    if not isinstance(items, list) or not items:
        raise ImageGenError("Image API returned no image data")

    for index, item in enumerate(items, start=1):
        if not isinstance(item, dict):
            raise ImageGenError("Image API returned an invalid image item")
        content_type = ""
        if item.get("b64_json"):
            try:
                data = base64.b64decode(item["b64_json"], validate=True)
            except (binascii.Error, ValueError, TypeError) as exc:
                raise ImageGenError("Image API returned invalid base64 image data") from exc
        elif item.get("url"):
            data, content_type = _download_image(
                str(item["url"]), endpoint, key, timeout
            )
        else:
            raise ImageGenError("Image item has neither url nor b64_json")

        if not data or len(data) > MAX_IMAGE_BYTES:
            raise ImageGenError("Generated image is empty or too large")
        suffix = _image_extension(data, content_type)
        final_path = output_dir / f"image-{stamp}-{run_id}-{index}{suffix}"
        temp_path = final_path.with_suffix(final_path.suffix + ".part")
        temp_path.write_bytes(data)
        temp_path.replace(final_path)
        paths.append(str(final_path.resolve()))
    return paths


def preview_paths(paths: Iterable[str]) -> list[str]:
    """Return absolute paths normalized for the chat renderer's Markdown URLs."""
    return [Path(path).resolve().as_posix() for path in paths]


def normalize_task_id(value: str | None = None) -> str:
    """Return a unique, filename-safe task id supplied before the API call."""
    if value:
        task_id = value.strip()
        if not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9._-]{7,127}", task_id):
            raise ImageGenError(
                "--task-id must be 8-128 characters using letters, numbers, dot, dash, or underscore"
            )
        return task_id
    return f"task-{time.time_ns()}-{uuid.uuid4().hex[:12]}"


def result_record_path(output_dir: Path, task_id: str) -> Path:
    return output_dir.expanduser().resolve() / f"result-{task_id}.json"


def ensure_new_task(output_dir: Path, task_id: str) -> None:
    if result_record_path(output_dir, task_id).exists():
        raise ImageGenError(
            f"Task id already has a result; choose a new --task-id: {task_id}"
        )


def _utc_millis_text(timestamp_ms: int) -> str:
    seconds, millis = divmod(timestamp_ms, 1000)
    return f"{time.strftime('%Y-%m-%dT%H:%M:%S', time.gmtime(seconds))}.{millis:03d}Z"


def _schedule_result_hide(path: Path) -> bool:
    """Hide a delivered result later without delaying stdout or command exit."""
    if os.name != "nt":
        return False
    helper = Path(__file__).resolve().with_name("hide_result.py")
    if not helper.is_file():
        return False
    try:
        subprocess.Popen(
            [
                sys.executable,
                str(helper),
                str(path),
                "--delay-ms",
                str(RESULT_HIDE_DELAY_MS),
            ],
            stdin=subprocess.DEVNULL,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            close_fds=True,
            creationflags=0x08000000 | 0x00000008,
        )
    except OSError:
        return False
    return True


def emit_success(
    payload: dict[str, Any],
    output_dir: Path,
    task_id: str,
    request_started_at_ms: int,
) -> dict[str, Any]:
    """Atomically persist and emit the exact current-task result once."""
    completed_at_ms = max(time.time_ns() // 1_000_000, request_started_at_ms)
    result_path = result_record_path(output_dir, task_id)
    result_path.parent.mkdir(parents=True, exist_ok=True)
    enriched = dict(payload)
    enriched.update(
        {
            "task_id": task_id,
            "request_started_at_ms": request_started_at_ms,
            "request_started_at": _utc_millis_text(request_started_at_ms),
            "completed_at_ms": completed_at_ms,
            "completed_at": _utc_millis_text(completed_at_ms),
            "result_file": result_path.as_posix(),
            "result_match": {
                "task_id": task_id,
                "not_before_ms": request_started_at_ms,
                "completed_at_ms": completed_at_ms,
            },
            "result_hide_delay_ms": RESULT_HIDE_DELAY_MS if os.name == "nt" else None,
        }
    )
    temp_path = result_path.with_suffix(result_path.suffix + f".{uuid.uuid4().hex}.tmp")
    try:
        temp_path.write_text(
            json.dumps(enriched, ensure_ascii=False, indent=2), encoding="utf-8"
        )
        temp_path.replace(result_path)
    except OSError as exc:
        try:
            temp_path.unlink(missing_ok=True)
        except OSError:
            pass
        raise ImageGenError(f"Unable to save the current task result JSON: {exc}") from exc

    print(json.dumps(enriched, ensure_ascii=False), flush=True)
    _schedule_result_hide(result_path)
    return enriched


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--prompt",
        help="Prompt text; GPT Image 2 upstream limit is 1024 characters (overlong text is compacted)",
    )
    parser.add_argument("--model", help="Model id; defaults to IMAGEGEN_MODEL or gpt-image-2")
    parser.add_argument(
        "--image",
        "--reference-image",
        dest="images",
        action="append",
        metavar="PATH",
        help="Local input/reference image; repeat for multiple images and enable edit mode",
    )
    parser.add_argument(
        "--reference-url",
        dest="reference_urls",
        action="append",
        metavar="URL",
        help="Public reference image URL; repeat up to 16 times for JSON edit requests",
    )
    parser.add_argument(
        "--mask",
        metavar="PATH",
        help="Optional local PNG/JPEG mask for the edit request",
    )
    parser.add_argument(
        "--mode",
        choices=("auto", "generate", "edit"),
        default="auto",
        help="Request mode; auto selects edit when --image is supplied",
    )
    parser.add_argument("--size", help="1K, 2K, 4K, or WIDTHxHEIGHT; defaults to 1K")
    parser.add_argument(
        "--aspect-ratio",
        default="auto",
        choices=sorted(ASPECT_RATIOS),
        help="Upstream aspect ratio for JSON generation/edit requests",
    )
    parser.add_argument("--n", type=int, default=1)
    parser.add_argument("--quality", choices=sorted(QUALITY_VALUES), default="auto")
    parser.add_argument("--stream", action="store_true", help="Request SSE output")
    parser.add_argument(
        "--async",
        dest="async_mode",
        action="store_true",
        help="Submit an async task and poll /v1/status/{task_id}",
    )
    parser.add_argument("--webhook", help="Public HTTPS callback URL for async tasks")
    parser.add_argument("--metadata", help="Lightweight JSON object attached to async tasks")
    parser.add_argument("--background")
    parser.add_argument("--input-fidelity")
    parser.add_argument("--out-dir", type=Path)
    parser.add_argument(
        "--task-id",
        help="Unique id for matching this command's result without scanning output directories",
    )
    parser.add_argument(
        "--output-size",
        help="本地最终输出尺寸 WIDTHxHEIGHT；生成完成后精确缩放/裁剪，不发送给模型",
    )
    parser.add_argument(
        "--fit",
        choices=("cover", "contain", "fill", "inside", "outside"),
        default="cover",
        help="本地输出尺寸的适配方式，默认 cover",
    )
    parser.add_argument(
        "--position",
        choices=(
            "center",
            "top",
            "bottom",
            "left",
            "right",
            "top-left",
            "top-right",
            "bottom-left",
            "bottom-right",
        ),
        default="center",
        help="cover/contain 裁剪或留白位置，默认 center",
    )
    parser.add_argument(
        "--crop",
        help="本地像素裁剪区域 x,y,width,height；可与 --output-size 组合",
    )
    parser.add_argument(
        "--output-format",
        choices=("same", "png", "jpeg", "jpg", "webp", "avif"),
        default="same",
        help="本地最终输出格式，默认保持模型返回格式",
    )
    parser.add_argument(
        "--output-quality",
        type=int,
        help="本地 JPEG/WebP/AVIF 质量 1-100；不传则使用 90",
    )
    parser.add_argument(
        "--output-background",
        help="本地 contain/JPEG 画布背景色，例如 #FFFFFF 或 #RRGGBBAA",
    )
    parser.add_argument(
        "--postprocess-dir",
        type=Path,
        help="本地后处理输出目录；默认使用原图目录下的 processed 子目录",
    )
    parser.add_argument(
        "--process-only",
        action="store_true",
        help="只处理已有 --image 文件，不调用图片 API",
    )
    parser.add_argument(
        "--timeout",
        type=int,
        default=600,
        help="Overall request/task timeout in seconds (10-600; default 600)",
    )
    parser.add_argument("--check-config", action="store_true")
    return parser.parse_args()


def main() -> int:
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8")
    if hasattr(sys.stderr, "reconfigure"):
        sys.stderr.reconfigure(encoding="utf-8")
    args = parse_args()
    request_started_at_ms = time.time_ns() // 1_000_000
    task_id: str | None = None
    try:
        if args.n < 1 or args.n > 4:
            raise ImageGenError("Image count must be between 1 and 4")
        if args.timeout < 10 or args.timeout > 600:
            raise ImageGenError("Timeout must be between 10 and 600 seconds")
        if args.output_quality is not None and not 1 <= args.output_quality <= 100:
            raise ImageGenError("--output-quality must be between 1 and 100")
        requested_size = normalize_size(args.size or "1K")

        image_paths = list(args.images or [])
        reference_urls = list(args.reference_urls or [])
        if args.process_only:
            task_id = normalize_task_id(args.task_id)
            if not image_paths:
                raise ImageGenError("--process-only requires at least one --image file")
            if reference_urls or args.mask or args.stream or args.async_mode or args.webhook:
                raise ImageGenError(
                    "--process-only only accepts local --image files and local post-processing options"
                )
            if (
                args.output_size is None
                and args.crop is None
                and args.output_format == "same"
                and args.output_background is None
            ):
                raise ImageGenError(
                    "--process-only requires --output-size, --crop, or --output-format"
                )
            output_dir = args.postprocess_dir or args.out_dir or (
                Path.home() / ".codex" / "generated_images" / SKILL_NAME / "processed"
            )
            ensure_new_task(output_dir, task_id)
            try:
                processed = process_many(
                    image_paths,
                    output_dir,
                    output_size=args.output_size,
                    fit=args.fit,
                    position=args.position,
                    crop=args.crop,
                    output_format=args.output_format,
                    quality=args.output_quality or 90,
                    background_color=args.output_background,
                )
            except PostprocessError as exc:
                raise ImageGenError(str(exc)) from exc
            files = [item["output"] for item in processed]
            preview_files = preview_paths(files)
            emit_success(
                {
                    "ok": True,
                    "skill_name": SKILL_NAME,
                    "version": SKILL_VERSION,
                    "mode": "local-process",
                    "count": len(files),
                    "files": files,
                    "original_files": preview_paths(image_paths),
                    "processed_files": files,
                    "preview_files": preview_files,
                    "download_files": preview_files,
                    "postprocess_manifest": str(Path(output_dir).resolve() / "postprocess-manifest.json"),
                },
                output_dir,
                task_id,
                request_started_at_ms,
            )
            return 0

        base_url, key, model, source = discover_credentials()
        model = (args.model or model).strip()
        generation_url = generation_endpoint(base_url)
        edit_url = edit_endpoint(base_url)
        if args.check_config:
            print(
                json.dumps(
                    {
                        "ok": True,
                        "skill_name": SKILL_NAME,
                        "version": SKILL_VERSION,
                        "credential_source": source,
                        "model": model,
                        "supported_models": ["gpt-image-2", "gpt-image-2-pro"],
                        "prompt_limit": PROMPT_MAX_CHARS,
                        "supported_modes": [
                            "generate",
                            "edit",
                            "url-reference-edit",
                            "async",
                            "stream",
                            "local-process",
                        ],
                    },
                    ensure_ascii=False,
                )
            )
            return 0

        task_id = normalize_task_id(args.task_id)
        output_dir = args.out_dir or (
            Path.home() / ".codex" / "generated_images" / SKILL_NAME
        )
        ensure_new_task(output_dir, task_id)

        raw_prompt = (args.prompt or "").strip()
        if not raw_prompt:
            raise ImageGenError("Prompt must not be empty")
        original_prompt_chars = len(raw_prompt)
        prompt, prompt_compacted = compact_prompt(raw_prompt)

        quality = validate_quality(args.quality)
        aspect_ratio = validate_aspect_ratio(args.aspect_ratio)
        aspect_ratio_source = "user" if aspect_ratio != "auto" else "model_default"
        if args.output_size:
            try:
                output_width, output_height = parse_output_size(args.output_size)
            except PostprocessError as exc:
                raise ImageGenError(str(exc)) from exc
            if args.size is None:
                longest = max(output_width, output_height)
                requested_size = "1K" if longest <= 1024 else "2K" if longest <= 2048 else "4K"
            if aspect_ratio == "auto":
                aspect_ratio = (
                    "1:1"
                    if output_width == output_height
                    else "3:2"
                    if output_width > output_height
                    else "2:3"
                )
                aspect_ratio_source = "output_size"
        if image_paths and reference_urls:
            raise ImageGenError("Use --image or --reference-url, not both")
        if args.mode == "generate" and (image_paths or reference_urls or args.mask):
            raise ImageGenError("--mode generate cannot be combined with reference images")
        if args.mode == "edit" and not (image_paths or reference_urls):
            raise ImageGenError("--mode edit requires --image or --reference-url")
        if args.mask and not image_paths:
            raise ImageGenError("--mask requires at least one local --image")
        if args.mask and not mask_support_enabled(model):
            raise ImageGenError(
                "当前模型编辑通道未启用本地遮罩；本次请求未发送，也不会扣费。"
                "请移除 --mask，使用整图参考编辑，并在提示词中说明需要修改的区域。"
                f"仅当中转站确认该模型支持 mask 后，才可设置 {MASK_SUPPORT_ENV}=1。"
            )
        if len(image_paths) + len(reference_urls) > MAX_INPUT_IMAGES:
            raise ImageGenError(f"At most {MAX_INPUT_IMAGES} reference images are supported")
        if args.webhook and not args.async_mode:
            raise ImageGenError("--webhook requires --async")
        if args.metadata:
            try:
                metadata = json.loads(args.metadata)
            except json.JSONDecodeError as exc:
                raise ImageGenError("--metadata must be a valid JSON object") from exc
            if not isinstance(metadata, dict):
                raise ImageGenError("--metadata must be a JSON object")
        else:
            metadata = None
        if image_paths and (args.stream or args.async_mode) and model not in {
            "gpt-image-2",
            "gpt-image-2-pro",
        }:
            raise ImageGenError(
                "This relay only supports --stream/--async for local GPT Image 2 edits"
            )

        mode = "edit" if (image_paths or reference_urls) else "generate"
        if image_paths and aspect_ratio == "auto":
            aspect_ratio, aspect_ratio_source = resolve_aspect_ratio(
                aspect_ratio, image_paths
            )
        edit_input_size = None
        input_bytes = None
        if image_paths:
            input_bytes = _input_image_bytes(image_paths, args.mask)
            edit_input_size = legacy_pixel_size(requested_size, aspect_ratio)
            size = edit_input_size
            size = edit_working_size(size, model)
        else:
            size = requested_size
            if reference_urls:
                edit_input_size = requested_size

        requested_async = args.async_mode
        auto_async = bool(
            image_paths
            and input_bytes is not None
            and should_auto_async_local_edit(
                size,
                model,
                len(image_paths),
                input_bytes,
                bool(args.mask),
            )
        )
        async_mode = args.async_mode or auto_async
        async_reason = "large_local_edit" if auto_async else None
        async_fallback = None
        if image_paths and args.metadata and auto_async:
            raise ImageGenError(
                "Metadata for a large local edit requires explicit --async; "
                "the automatic async path does not attach metadata to multipart requests"
            )

        options = _option_fields(quality, args.background, args.input_fidelity)
        if image_paths:
            # The pinned relay can convert GPT Image 2 multipart edits to its
            # JSON reference-image flow, so preserve the requested ratio in
            # the multipart fields as well. Older multipart providers may
            # ignore this extra field.
            options["aspect_ratio"] = aspect_ratio
            if args.stream:
                options["stream"] = "true"
            if async_mode:
                options["async"] = "true"
            result = call_edit_api(
                edit_url,
                key,
                model,
                prompt,
                size,
                args.n,
                image_paths,
                args.mask,
                args.timeout,
                options,
            )
            result_endpoint = generation_url if async_mode else edit_url
            if async_mode:
                result = wait_for_task(result, generation_url, key, args.timeout)
        else:
            options["aspect_ratio"] = aspect_ratio
            result = call_api(
                generation_url,
                key,
                model,
                prompt,
                size,
                args.n,
                args.timeout,
                options,
                aspect_ratio=aspect_ratio,
                image_urls=reference_urls or None,
                stream=args.stream,
                async_mode=async_mode,
                webhook=args.webhook or "",
                metadata=metadata,
            )
            result_endpoint = generation_url
            if async_mode:
                result = wait_for_task(result, generation_url, key, args.timeout)
        files = save_images(
            result,
            result_endpoint,
            key,
            output_dir,
            args.timeout,
        )
        original_files = preview_paths(files)
        processed_files = files.copy()
        postprocess_requested = bool(
            args.output_size
            or args.crop
            or args.output_format != "same"
            or args.output_quality is not None
            or args.output_background
        )
        postprocess_manifest = None
        if postprocess_requested:
            processed_dir = args.postprocess_dir or (output_dir / "processed")
            try:
                processed = process_many(
                    files,
                    processed_dir,
                    output_size=args.output_size,
                    fit=args.fit,
                    position=args.position,
                    crop=args.crop,
                    output_format=args.output_format,
                    quality=args.output_quality or 90,
                    background_color=args.output_background,
                )
            except PostprocessError as exc:
                print(
                    json.dumps(
                        {
                            "ok": False,
                            "error": f"图片已生成，但本地后处理失败；原始图片仍保留在 {output_dir}: {exc}",
                            "mode": mode,
                            "model": model,
                            "original_files": original_files,
                            "processed_files": [],
                            "postprocess": True,
                        },
                        ensure_ascii=False,
                    ),
                    file=sys.stderr,
                )
                return 1
            processed_files = [item["output"] for item in processed]
            postprocess_manifest = str(Path(processed_dir).resolve() / "postprocess-manifest.json")
        preview_files = preview_paths(processed_files)
        download_files = preview_files.copy()
        emit_success(
            {
                "ok": True,
                "skill_name": SKILL_NAME,
                "version": SKILL_VERSION,
                "mode": mode,
                "model": model,
                "count": len(files),
                "prompt_limit": PROMPT_MAX_CHARS,
                "prompt_compacted": prompt_compacted,
                "prompt_original_chars": original_prompt_chars,
                "prompt_chars": len(prompt),
                "size": size,
                "requested_size": requested_size,
                "edit_size": size if mode == "edit" else None,
                "resized_for_edit": mode == "edit" and size != edit_input_size,
                "quality": quality,
                "aspect_ratio": aspect_ratio,
                "aspect_ratio_source": aspect_ratio_source,
                "async": async_mode,
                "async_requested": requested_async,
                "async_auto": auto_async,
                "async_reason": async_reason,
                "async_fallback": async_fallback,
                "stream": args.stream,
                "input_images": len(image_paths) + len(reference_urls),
                "input_bytes": input_bytes,
                "mask": bool(args.mask),
                "files": files,
                "original_files": original_files,
                "processed_files": processed_files,
                "postprocess": postprocess_requested,
                "postprocess_manifest": postprocess_manifest,
                "preview_files": preview_files,
                "download_files": download_files,
            },
            output_dir,
            task_id,
            request_started_at_ms,
        )
        return 0
    except ImageGenError as exc:
        print(
            json.dumps(
                {
                    "ok": False,
                    "skill_name": SKILL_NAME,
                    "version": SKILL_VERSION,
                    "task_id": task_id,
                    "request_started_at_ms": request_started_at_ms,
                    "error": str(exc),
                },
                ensure_ascii=False,
            ),
            file=sys.stderr,
        )
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
